
import os
import csv
import json
from flask import Flask, render_template, jsonify, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "final_cleaned_travel_data.csv")

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)


_cache = None


_TRAIT_CN = {
    "culture": "文化",
    "adventure": "冒险",
    "nature": "自然",
    "beaches": "海滩",
    "nightlife": "夜生活",
    "cuisine": "美食",
    "wellness": "康养",
    "urban": "都市",
    "seclusion": "隐居",
}


def _enrich(row):
    """为前端补充缺失字段（short_description / 显示用的特质标签等）。"""
    trait_en = (row.get("top_trait") or "").strip()
    trait_cn = _TRAIT_CN.get(trait_en, trait_en or "特色")
    city = row.get("city", "")
    country = row.get("country", "")
    region_cn = {
        "europe": "欧洲", "north_america": "北美", "asia": "亚洲",
        "africa": "非洲", "south_america": "南美", "oceania": "大洋洲",
        "middle_east": "中东",
    }.get((row.get("region") or "").strip(), row.get("region", ""))

    if not row.get("short_description"):
        row["short_description"] = (
            f"{city}位于{region_cn}的{country}，以{trait_cn}为特色，"
            f"适合{row.get('ideal_durations') or '各类旅行者'}。"
        )
    return row


def _load_data():
    """缓存 CSV 数据到内存。"""
    global _cache
    if _cache is not None:
        return _cache
    rows = []
    with open(DATA_PATH, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            clean = {k.strip(): v for k, v in row.items()}
            rows.append(_enrich(clean))
    _cache = rows
    return rows


@app.route("/")
def index():
    """首页 - 全球旅游城市数据大屏"""
    return render_template("dashboard.html")


@app.route("/city-list")
def city_list():
    """城市列表页（可选的独立页面）"""
    return send_from_directory(BASE_DIR, "index.html")


@app.route("/globe")
def travel_globe():
    """3D 地球视图"""
    return render_template("travel_globe.html")


@app.route("/data/<path:filename>")
def serve_data_file(filename):
    """通用数据文件路由"""
    return send_from_directory(os.path.join(BASE_DIR, "data"), filename)


@app.route("/static/images/travel_images/<path:filename>")
def serve_travel_image(filename):
    """旅行城市图片路由"""
    image_dir = os.path.join(BASE_DIR, "static", "images", "travel_images")
    if not os.path.isdir(image_dir):
        return "", 404
    return send_from_directory(image_dir, filename)


@app.route("/data/final_cleaned_travel_data.csv")
def serve_csv():
    """前端 dashboard.html 通过相对路径加载 CSV"""
    return send_from_directory(
        os.path.join(BASE_DIR, "data"),
        "final_cleaned_travel_data.csv",
        mimetype="text/csv; charset=utf-8",
    )


@app.route("/api/cities")
def api_cities():
    """返回所有城市名称列表（供 city-list 页面使用）"""
    rows = _load_data()
    cities = sorted({row.get("city", "") for row in rows if row.get("city")})
    return jsonify(list(cities))


@app.route("/api/city/<path:city_name>")
def api_city_detail(city_name):
    """按城市名返回该城市的详细信息"""
    rows = _load_data()
    for row in rows:
        if row.get("city", "").strip() == city_name.strip():
            return jsonify(row)
    return jsonify({"error": f"未找到城市: {city_name}"}), 404


@app.route("/explore")
def explore():
    """探索城市页 - 城市卡片网格/列表视图"""
    rows = _load_data()
    return render_template("explore.html", cities=rows)


@app.route("/city/<city_id>")
def city_detail(city_id):
    """城市详情页 - 根据 ID 查找"""
    rows = _load_data()
    for row in rows:
        if row.get("id", "").strip() == city_id.strip():
            return render_template("city_detail.html", city=row)
    return f"城市未找到 (ID: {city_id})", 404


@app.route("/api/all")
def api_all():
    """返回所有数据（调试用）"""
    return jsonify(_load_data())


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
